library(testthat)
library(forecast)

test_check("forecast")
